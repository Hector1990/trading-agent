"""Web application package for TradingAgents."""
